<!-- Header -->
<div>
  <div tabindex="400" class="card MJF62LC-nb-b MJF62LC-nb-e" id="gjssap">
    <input tabindex="-1" role="presentation" style="opacity: 0; height: 1px; width: 1px; z-index: -1; overflow: hidden; position: absolute;" type="text">
    <div class="MJF62LC-nb-c">
      <span class="material-icons-extended MJF62LC-u-d MJF62LC-u-b MJF62LC-nb-d" role="presentation" aria-hidden="true" id="gjssai">notifications</span>
      <div class="gwt-Label MJF62LC-nb-a" id="gjsasl">Turn on email alerts for this search</div>
      <div tabindex="0" class="MJF62LC-Jb-b" style="" id="gjssas">
        <input tabindex="-1" role="presentation" style="opacity: 0; height: 1px; width: 1px; z-index: -1; overflow: hidden; position: absolute;" aria-hidden="true" type="text">
        <div>
          <input tabindex="-1" type="checkbox">
          <div class="MJF62LC-Jb-d"></div>
          <div class="MJF62LC-Jb-c"></div>
        </div>
      </div>
      <a class="MJF62LC-x-d MJF62LC-x-w MJF62LC-x-k MJF62LC-x-v" style="display: none;" aria-hidden="true" id="gjssaml" href="https://careers.google.com/jobs#%21t=al&amp;" rel="nofollow">
        <span>
          <span class="MJF62LC-x-e">Manage</span>
        </span>
      </a>
    </div>
  </div>
</div>
<!-- End Header -->
