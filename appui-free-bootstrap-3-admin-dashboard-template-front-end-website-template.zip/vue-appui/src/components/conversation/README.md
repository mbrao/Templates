# Conversation

Conversation is a component used in chats.
