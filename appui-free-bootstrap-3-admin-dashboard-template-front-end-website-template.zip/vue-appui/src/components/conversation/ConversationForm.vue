<template>
  <div class="conversation__form card card-body layout-row">
    <div class="input-group">
      <span class="input-group-btn">
        <button class="btn btn-light btn-sm material-icons layout-column" type="button">
          insert_emoticon
        </button>
      </span>
      <input class="conversation__input form-control form-control-sm" type="text" placeholder="Send a message...">
      <span class="input-group-btn">
        <button class="btn btn-light btn-sm material-icons" type="button">image</button>
      </span>
      <span class="input-group-btn">
        <button class="btn btn-light btn-sm material-icons" type="button">mic</button>
      </span>
      <span class="input-group-btn">
        <button class="btn btn-light btn-sm material-icons" type="button">thumb_up</button>
      </span>
    </div>
  </div>
</template>
