# Scorecard

Scorecard is a data-visualization component.

## Usage

```html
<div class="scorecard">
  <div class="scorecard__value">$999</div>
  <div class="scorecard__label">App revenue</div>
</div>
```
