import AnalyticsReport from './AnalyticsReport'

export default AnalyticsReport
