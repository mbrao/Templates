import SocialReport from './SocialReport'

export default SocialReport
