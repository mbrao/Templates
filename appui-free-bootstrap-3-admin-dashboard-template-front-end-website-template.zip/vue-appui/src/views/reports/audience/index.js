import AudienceReport from './AudienceReport'

export default AudienceReport
