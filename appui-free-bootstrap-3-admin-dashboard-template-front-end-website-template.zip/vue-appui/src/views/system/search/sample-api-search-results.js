const searchResults = [
  {
    id: 0,
    url: 'https://awesomewebsite.com',
    name: 'Ut aliquid constituto vel, lorem fabulas mediocrem sit an',
    image: '/static/images/logo_instagram.svg',
    description: 'Vis modus aperiam rationibus in, vel nonumes epicuri vivendum et, reformidans reprehendunt an quo. Per eripuit inimicus periculis ut, mel ad nostro assentior.',
    datePublished: '9 days ago'
  },
  {
    id: 1,
    url: 'https://awesomewebsite.com',
    name: 'Laudem iisque nec ei vis etiam recusabo',
    image: '/static/images/logo_weibo.svg',
    description: 'Lorem ipsum dolor sit amet, mea scripserit signiferumque ad. Eirmod fastidii sit ut. Has te magna ponderum.',
    datePublished: '10 days ago'
  },
  {
    id: 2,
    url: 'https://awesomewebsite.com',
    name: 'Exerci latine sea in, nam alia verterem concludaturque ut',
    image: '/static/images/logo_twitter.svg',
    description: 'Vis at fugit argumentum, everti viderer no has, feugiat molestiae sadipscing ut usu.',
    datePublished: '12 days ago'
  },
  {
    id: 3,
    url: 'https://awesomewebsite.com',
    name: 'Duo ex simul nullam graeco, te natum graeci fabulas per',
    image: '/static/images/logo_facebook.svg',
    description: 'Vis at fugit argumentum, everti viderer no has, feugiat molestiae sadipscing ut usu.',
    datePublished: '1 month ago'
  }
]

export default searchResults
