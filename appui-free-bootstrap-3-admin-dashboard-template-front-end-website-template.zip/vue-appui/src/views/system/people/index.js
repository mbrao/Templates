import People from './People'

export default People
