import Mail from './Mail'

export default Mail
