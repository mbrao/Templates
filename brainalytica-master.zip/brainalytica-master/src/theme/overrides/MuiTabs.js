export default {
  indicator: {
    height: '4px'
  }
};
